const db = require('../db');

module.exports = {
  getAll: () => db.query('SELECT * FROM proverbs'),
  getById: (id) => db.query('SELECT * FROM proverbs WHERE id = $1', [id]),
  create: (data) => {
    const { textDari, textPashto, translationEn, meaning, category } = data;
    return db.query(
      `INSERT INTO proverbs (textDari, textPashto, translationEn, meaning, category)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [textDari, textPashto, translationEn, meaning, category]
    );
  },
  update: (id, data) => {
    const { textDari, textPashto, translationEn, meaning, category } = data;
    return db.query(
      `UPDATE proverbs SET textDari=$1, textPashto=$2, translationEn=$3, meaning=$4, category=$5 WHERE id=$6 RETURNING *`,
      [textDari, textPashto, translationEn, meaning, category, id]
    );
  },
  delete: (id) => db.query('DELETE FROM proverbs WHERE id = $1', [id])
};
